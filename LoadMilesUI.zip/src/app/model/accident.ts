export class AccidentFilters {

}
