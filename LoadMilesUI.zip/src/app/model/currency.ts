export class Currency {
    currencyName: String;
}