export class CustomersFilters {
    companyname: string;
    dba: any;
    firstname: string;
    middlename: string;
    lastname: string;
    dislpalyname: string;
    mcsf: any;
    usdot: any;
    fein: any;
    billto: any;
    paymentterms: any;
    address1: string;
    address2: string;
    city: string;
    state: string;
    zipcode: number;
    comments: string;
    memo: any;
    address3: string;
    address4: string;
    city1: string;
    state1: string;
    zipcode1: number;
    country: string;
    contact: any;
    homephone: number;
    cellphone: number;
    email: string;
    customeraccount: any;
    glaccount: any;
    

}
