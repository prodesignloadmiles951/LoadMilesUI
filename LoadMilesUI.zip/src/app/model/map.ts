export class MapFilters {

}
