export class FuelcardFilters {
    companyname: string;
    displayname: string;
    accountnumber: any;
    currency: any;
    discountrate: any;
    creditlimit: any;
    paymentterms: any;
    status: any;
    erpgl: any;
    contactname: string;
    phone: number;
    email: string;
    address1: string;
    address2: string;
    city: string;
    state: string;
    zipcode: any;
    country: string;
}
