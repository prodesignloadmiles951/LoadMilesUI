export class VendorExpenseDetails {
    expenseType: string;
    debitAccNo: string;
    billAmount: number;
    description: string;
    comment: string;
}