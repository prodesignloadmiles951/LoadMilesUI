export class Expense {
  name: String;
  expenseType: any;
  active: String;
}
